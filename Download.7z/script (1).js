// Fungsi untuk navigasi dan inisialisasi umum
document.addEventListener('DOMContentLoaded', function() {
    // Inisialisasi komponen yang dibutuhkan di semua halaman
    
    // Jika di halaman output, muat kode dari localStorage
    if (document.getElementById('full-output')) {
        const outputFrame = document.getElementById('full-output');
        const savedCode = localStorage.getItem('compiledCode');
        if (savedCode) {
            outputFrame.srcdoc = savedCode;
        }
        
        document.getElementById('back-btn').addEventListener('click', function() {
            window.location.href = 'editor.html';
        });
        
        document.getElementById('refresh-btn').addEventListener('click', function() {
            outputFrame.srcdoc = localStorage.getItem('compiledCode') || '';
        });
    }
    
    // Tambahkan event listener untuk semua link
    document.querySelectorAll('a').forEach(link => {
        link.addEventListener('click', function(e) {
            if (this.getAttribute('href') === '#') {
                e.preventDefault();
            }
        });
    });
});