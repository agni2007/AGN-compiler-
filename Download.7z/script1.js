document.addEventListener('DOMContentLoaded', function() {
    // Inisialisasi editor CodeMirror
    const htmlEditor = CodeMirror.fromTextArea(document.getElementById('html-editor'), {
        mode: 'htmlmixed',
        theme: 'dracula',
        lineNumbers: true,
        autoCloseTags: true,
        autoCloseBrackets: true,
        indentUnit: 4
    });
    
    const cssEditor = CodeMirror.fromTextArea(document.getElementById('css-editor'), {
        mode: 'css',
        theme: 'dracula',
        lineNumbers: true,
        autoCloseBrackets: true,
        indentUnit: 4
    });
    
    const jsEditor = CodeMirror.fromTextArea(document.getElementById('js-editor'), {
        mode: 'javascript',
        theme: 'dracula',
        lineNumbers: true,
        autoCloseBrackets: true,
        indentUnit: 4
    });
    
    // Tab switching
    const tabs = document.querySelectorAll('.tab-button');
    tabs.forEach(tab => {
        tab.addEventListener('click', function() {
            // Update tab UI
            tabs.forEach(t => t.classList.remove('active'));
            this.classList.add('active');
            
            // Show corresponding editor
            const tabName = this.getAttribute('data-tab');
            document.querySelectorAll('.editor-content .CodeMirror').forEach(editor => {
                editor.style.display = 'none';
            });
            
            if (tabName === 'html') {
                htmlEditor.display.wrapper.style.display = 'block';
                htmlEditor.refresh();
            } else if (tabName === 'css') {
                cssEditor.display.wrapper.style.display = 'block';
                cssEditor.refresh();
            } else if (tabName === 'js') {
                jsEditor.display.wrapper.style.display = 'block';
                jsEditor.refresh();
            }
        });
    });
    
    // Force show HTML editor on load
    cssEditor.display.wrapper.style.display = 'none';
    jsEditor.display.wrapper.style.display = 'none';
    
    // Run button functionality
    document.getElementById('run-btn').addEventListener('click', compileAndRun);
    
    // Clear button functionality
    document.getElementById('clear-btn').addEventListener('click', function() {
        if (confirm('Apakah Anda yakin ingin menghapus semua kode?')) {
            htmlEditor.setValue('');
            cssEditor.setValue('');
            jsEditor.setValue('');
        }
    });
    
    // Save button functionality (simpan ke localStorage)
    document.getElementById('save-btn').addEventListener('click', function() {
        const htmlCode = htmlEditor.getValue();
        const cssCode = cssEditor.getValue();
        const jsCode = jsEditor.getValue();
        
        localStorage.setItem('savedHTML', htmlCode);
        localStorage.setItem('savedCSS', cssCode);
        localStorage.setItem('savedJS', jsCode);
        
        alert('Kode berhasil disimpan!');
    });
    
    // Load saved code if exists
    if (localStorage.getItem('savedHTML')) {
        htmlEditor.setValue(localStorage.getItem('savedHTML'));
        cssEditor.setValue(localStorage.getItem('savedCSS'));
        jsEditor.setValue(localStorage.getItem('savedJS'));
    }
    
    // Auto-run on code change (optional)
    htmlEditor.on('change', debounce(compileAndRun, 1000));
    cssEditor.on('change', debounce(compileAndRun, 1000));
    jsEditor.on('change', debounce(compileAndRun, 1000));
    
    // Fungsi untuk compile dan run code
    function compileAndRun() {
        const htmlCode = htmlEditor.getValue();
        const cssCode = cssEditor.getValue();
        const jsCode = jsEditor.getValue();
        
        // Buat dokumen HTML lengkap
        const fullCode = `
            <!DOCTYPE html>
            <html>
            <head>
                <style>${cssCode}</style>
            </head>
            <body>
                ${htmlCode}
                <script>${jsCode}</script>
            </body>
            </html>
        `;
        
        // Tampilkan hasil di iframe
        const outputFrame = document.getElementById('output-frame');
        outputFrame.srcdoc = fullCode;
        
        // Simpan ke localStorage untuk halaman output
        localStorage.setItem('compiledCode', fullCode);
    }
    
    // Debounce function untuk membatasi frekuensi eksekusi
    function debounce(func, wait) {
        let timeout;
        return function() {
            const context = this, args = arguments;
            clearTimeout(timeout);
            timeout = setTimeout(function() {
                func.apply(context, args);
            }, wait);
        };
    }
});