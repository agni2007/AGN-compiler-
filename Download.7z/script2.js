document.addEventListener('DOMContentLoaded', function() {
    const examples = [
        {
            id: 1,
            title: "Halaman HTML Dasar",
            description: "Struktur dasar dokumen HTML",
            category: "html",
            html: `<!DOCTYPE html>
<html>
<head>
    <title>Halaman HTML Dasar</title>
</head>
<body>
    <h1>Selamat Datang</h1>
    <p>Ini adalah contoh halaman HTML dasar.</p>
    <ul>
        <li>Item 1</li>
        <li>Item 2</li>
        <li>Item 3</li>
    </ul>
</body>
</html>`,
            css: "",
            js: ""
        },
        {
            id: 2,
            title: "Tombol dengan CSS",
            description: "Membuat tombol yang menarik dengan CSS",
            category: "css",
            html: `<button class="fancy-button">Klik Saya</button>`,
            css: `.fancy-button {
    padding: 12px 24px;
    background: linear-gradient(to right, #4285f4, #34a853);
    color: white;
    border: none;
    border-radius: 30px;
    font-size: 16px;
    cursor: pointer;
    box-shadow: 0 4px 6px rgba(0,0,0,0.1);
    transition: all 0.3s ease;
}

.fancy-button:hover {
    transform: translateY(-2px);
    box-shadow: 0 6px 8px rgba(0,0,0,0.15);
}

.fancy-button:active {
    transform: translateY(0);
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
}`,
            js: ""
        },
        {
            id: 3,
            title: "Kalkulator Sederhana",
            description: "Kalkulator sederhana dengan JavaScript",
            category: "js",
            html: `<div class="calculator">
    <input type="text" id="display" readonly>
    <div class="buttons">
        <button onclick="appendToDisplay('7')">7</button>
        <button onclick="appendToDisplay('8')">8</button>
        <button onclick="appendToDisplay('9')">9</button>
        <button onclick="appendToDisplay('+')">+</button>
        <button onclick="appendToDisplay('4')">4</button>
        <button onclick="appendToDisplay('5')">5</button>
        <button onclick="appendToDisplay('6')">6</button>
        <button onclick="appendToDisplay('-')">-</button>
        <button onclick="appendToDisplay('1')">1</button>
        <button onclick="appendToDisplay('2')">2</button>
        <button onclick="appendToDisplay('3')">3</button>
        <button onclick="appendToDisplay('*')">×</button>
        <button onclick="appendToDisplay('0')">0</button>
        <button onclick="appendToDisplay('.')">.</button>
        <button onclick="calculate()">=</button>
        <button onclick="appendToDisplay('/')">÷</button>
    </div>
</div>`,
            css: `.calculator {
    width: 200px;
    margin: 0 auto;
    padding: 20px;
    background-color: #f1f3f4;
    border-radius: 10px;
}

#display {
    width: 100%;
    padding: 10px;
    margin-bottom: 10px;
    font-size: 18px;
    text-align: right;
}

.buttons {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 5px;
}

.buttons button {
    padding: 10px;
    font-size: 16px;
    border: none;
    border-radius: 5px;
    background-color: white;
    cursor: pointer;
}

.buttons button:hover {
    background-color: #e0e0e0;
}`,
            js: `let currentInput = '';

function appendToDisplay(value) {
    currentInput += value;
    document.getElementById('display').value = currentInput;
}

function calculate() {
    try {
        const result = eval(currentInput);
        document.getElementById('display').value = result;
        currentInput = result.toString();
    } catch (error) {
        document.getElementById('display').value = 'Error';
        currentInput = '';
    }
}`
        },
        {
            id: 4,
            title: "Galery Foto",
            description: "Galery foto responsif dengan CSS Grid",
            category: "project",
            html: `<div class="gallery">
    <h1>Galery Foto</h1>
    <div class="gallery-grid">
        <div class="gallery-item">
            <img src="https://via.placeholder.com/400x300" alt="Foto 1">
            <div class="caption">Foto 1</div>
        </div>
        <div class="gallery-item">
            <img src="https://via.placeholder.com/400x300" alt="Foto 2">
            <div class="caption">Foto 2</div>
        </div>
        <div class="gallery-item">
            <img src="https://via.placeholder.com/400x300" alt="Foto 3">
            <div class="caption">Foto 3</div>
        </div>
        <div class="gallery-item">
            <img src="https://via.placeholder.com/400x300" alt="Foto 4">
            <div class="caption">Foto 4</div>
        </div>
        <div class="gallery-item">
            <img src="https://via.placeholder.com/400x300" alt="Foto 5">
            <div class="caption">Foto 5</div>
        </div>
        <div class="gallery-item">
            <img src="https://via.placeholder.com/400x300" alt="Foto 6">
            <div class="caption">Foto 6</div>
        </div>
    </div>
</div>`,
            css: `.gallery {
    max-width: 1200px;
    margin: 0 auto;
    padding: 20px;
}

.gallery h1 {
    text-align: center;
    margin-bottom: 30px;
    color: #4285f4;
}

.gallery-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
    gap: 20px;
}

.gallery-item {
    border: 1px solid #ddd;
    border-radius: 8px;
    overflow: hidden;
    transition: transform 0.3s, box-shadow 0.3s;
}

.gallery-item:hover {
    transform: translateY(-5px);
    box-shadow: 0 10px 20px rgba(0,0,0,0.1);
}

.gallery-item img {
    width: 100%;
    height: auto;
    display: block;
}

.caption {
    padding: 15px;
    text-align: center;
    background-color: #f8f9fa;
}`,
            js: ""
        }
    ];
    
    const container = document.getElementById('examples-container');
    const categorySelect = document.getElementById('category-select');
    
    // Fungsi untuk menampilkan contoh
    function displayExamples(category = 'all') {
        container.innerHTML = '';
        
        const filteredExamples = category === 'all' 
            ? examples 
            : examples.filter(ex => ex.category === category);
        
        filteredExamples.forEach(example => {
            const exampleCard = document.createElement('div');
            exampleCard.className = 'example-card';
            exampleCard.innerHTML = `
                <h3>${example.title}</h3>
                <p>${example.description}</p>
                <div class="example-meta">
                    <span class="category-badge">${example.category.toUpperCase()}</span>
                    <button class="load-example-btn" data-id="${example.id}">Load</button>
                </div>
            `;
            container.appendChild(exampleCard);
        });
        
        // Tambahkan event listener untuk tombol load
        document.querySelectorAll('.load-example-btn').forEach(button => {
            button.addEventListener('click', function() {
                const exampleId = parseInt(this.getAttribute('data-id'));
                const example = examples.find(ex => ex.id === exampleId);
                
                if (example) {
                    // Simpan contoh ke localStorage
                    localStorage.setItem('exampleHTML', example.html);
                    localStorage.setItem('exampleCSS', example.css);
                    localStorage.setItem('exampleJS', example.js);
                    
                    // Redirect ke editor
                    window.location.href = 'editor.html';
                }
            });
        });
    }
    
    // Load contoh berdasarkan kategori yang dipilih
    categorySelect.addEventListener('change', function() {
        displayExamples(this.value);
    });
    
    // Tampilkan semua contoh saat pertama kali dimuat
    displayExamples();
    
    // Jika ada contoh yang dimuat dari halaman editor
    if (window.location.search.includes('loadExample=true')) {
        const html = localStorage.getItem('exampleHTML') || '';
        const css = localStorage.getItem('exampleCSS') || '';
        const js = localStorage.getItem('exampleJS') || '';
        
        // Hapus data setelah dimuat
        localStorage.removeItem('exampleHTML');
        localStorage.removeItem('exampleCSS');
        localStorage.removeItem('exampleJS');
        
        // Isi editor dengan contoh kode
        if (typeof htmlEditor !== 'undefined') {
            htmlEditor.setValue(html);
            cssEditor.setValue(css);
            jsEditor.setValue(js);
            compileAndRun();
        }
    }
});